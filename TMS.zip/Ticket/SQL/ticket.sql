-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 06, 2024 at 07:59 PM
-- Server version: 8.0.31
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ticket`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
CREATE TABLE IF NOT EXISTS `department` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Department` varchar(211) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `Department`) VALUES
(1, 'Civil'),
(2, 'Land Management Cell'),
(3, 'Finance'),
(4, 'General Administration'),
(5, 'Quality'),
(6, 'Electrical'),
(7, 'Signaling and Telecommunication'),
(8, 'CS and Legal'),
(9, 'Rolling Stock'),
(10, 'Environment'),
(12, 'Operations'),
(13, 'HR'),
(14, 'Architecture'),
(15, 'Public Relation'),
(16, 'Safety Health and Environment'),
(17, 'Security'),
(18, 'Store'),
(19, 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `designation`
--

DROP TABLE IF EXISTS `designation`;
CREATE TABLE IF NOT EXISTS `designation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Designation` varchar(211) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `designation`
--

INSERT INTO `designation` (`id`, `Designation`) VALUES
(1, 'Chief Town Planner'),
(2, 'Deputy Collector'),
(3, 'Director Finance'),
(4, 'Managing Director'),
(5, 'Chief Project Manager'),
(6, 'OSD'),
(7, 'Additional General Manager'),
(8, 'Deputy General Manager'),
(10, 'Company Secereatory'),
(11, 'Joint General Manager'),
(13, 'Joint Chief Engineer'),
(14, 'Project Director'),
(15, 'Chief Engineer'),
(16, 'General Manager'),
(17, 'Deputy Chief Engineer'),
(18, 'Chief Architect'),
(20, 'Chief Electrical Engineer'),
(23, 'Sr Fire Officer'),
(24, 'Security Commissioner'),
(25, 'General Manager'),
(26, 'Chief  Security Commissioner'),
(27, 'Consultant'),
(28, 'Director Works & Infrastructure');

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

DROP TABLE IF EXISTS `equipment`;
CREATE TABLE IF NOT EXISTS `equipment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `equipment_type` varchar(211) COLLATE utf8mb4_general_ci NOT NULL,
  `equipment_description` varchar(211) COLLATE utf8mb4_general_ci NOT NULL,
  `equipment_sno` varchar(211) COLLATE utf8mb4_general_ci NOT NULL,
  `location` varchar(251) COLLATE utf8mb4_general_ci NOT NULL,
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`id`, `user_id`, `equipment_type`, `equipment_description`, `equipment_sno`, `location`, `date_added`, `date_updated`, `status`) VALUES
(2, 21, 'Printer', 'ggkjk', '123', 'PP', '2024-03-03 10:48:51', '2024-03-14 15:53:16', 1),
(6, 19, 'Cartridges Print', '6565', '6565', '656', '2024-03-14 15:44:00', '2024-03-14 15:51:29', 1);

-- --------------------------------------------------------

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
CREATE TABLE IF NOT EXISTS `system_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `contact` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `address` text COLLATE utf8mb4_general_ci NOT NULL,
  `cover_img` text COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_settings`
--

INSERT INTO `system_settings` (`id`, `name`, `email`, `contact`, `address`, `cover_img`) VALUES
(1, 'Ticketing System', 'info@sample.comm', '7065315368', 'LKO', '');

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
CREATE TABLE IF NOT EXISTS `ticket` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(80) COLLATE utf8mb4_general_ci NOT NULL,
  `equipment_id` varchar(80) COLLATE utf8mb4_general_ci NOT NULL,
  `ticket_description` varchar(211) COLLATE utf8mb4_general_ci NOT NULL,
  `ticket_raisedate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `assignee` varchar(211) COLLATE utf8mb4_general_ci NOT NULL,
  `date_added` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int NOT NULL COMMENT '1=''Open'',2=''Pending'',3=''Resolve'',4=''comfrim by user''',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`id`, `user_id`, `equipment_id`, `ticket_description`, `ticket_raisedate`, `assignee`, `date_added`, `date_updated`, `status`) VALUES
(1, '19', '6', 'Hello', '2024-03-15 15:52:54', '20', '2024-03-15 15:52:54', '2024-03-15 15:53:23', 2);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_status`
--

DROP TABLE IF EXISTS `ticket_status`;
CREATE TABLE IF NOT EXISTS `ticket_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `it_admin_id` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `ticket_id` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `ticket_comment` text COLLATE utf8mb4_general_ci NOT NULL,
  `dateadded` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket_status`
--

INSERT INTO `ticket_status` (`id`, `it_admin_id`, `ticket_id`, `ticket_comment`, `dateadded`, `status`) VALUES
(1, '18', '1', 'Hello', '2024-03-15 15:53:23', '2');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(251) COLLATE utf8mb4_general_ci NOT NULL,
  `firstname` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `lastname` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb4_general_ci NOT NULL,
  `password` text COLLATE utf8mb4_general_ci NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '2' COMMENT '1 = Super Admin, 2 = Admin , 3=staff',
  `designation_id` int NOT NULL,
  `department_id` int NOT NULL,
  `avatar` text COLLATE utf8mb4_general_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `firstname`, `lastname`, `email`, `password`, `type`, `designation_id`, `department_id`, `avatar`, `date_created`, `status`) VALUES
(1, 'admin', 'Shivam', '', 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3', 1, 1, 1, '69360-20230411_155549-01.png', '2020-11-26 10:57:04', 1),
(18, '1152', 'Amaan', '', 'amaan@gmail.com', '45f31d16b1058d586fc3be7207b58053', 2, 1, 1, '20750-20231009_090521.jpg', '2024-03-02 20:21:14', 1),
(19, '3807', 'Shivanshu', '', 'shivanshu@gmail.com', '43a115cbd6f4788924537365be3d6012', 3, 1, 1, '75373-20231118_111917.jpg', '2024-03-02 20:23:08', 1),
(20, '12345', 'Rahul', '', 'ara@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 2, 1, 2, '65460-20230611_125334 (1).png', '2024-03-03 12:58:50', 1),
(21, '3808', 'Shivanshu Rai', '', 'shivanshu@gmail.com', '43a115cbd6f4788924537365be3d6012', 3, 1, 1, '75373-20231118_111917.jpg', '2024-03-02 20:23:08', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
