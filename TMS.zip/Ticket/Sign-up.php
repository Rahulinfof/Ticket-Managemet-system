<?php require('conn/conn.php'); ?>
<!DOCTYPE html>

<html lang="en" class="light-style layout-wide  customizer-hide" dir="ltr" data-theme="theme-semi-dark" data-assets-path="assets/" data-template="vertical-menu-template-semi-dark">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Sign Up</title>
    <meta name="description" content="" />
    <meta name="keywords" content="">
      
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&amp;family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&amp;display=swap" rel="stylesheet">

    <!-- Icons -->
    <link rel="stylesheet" href="assets/vendor/fonts/boxicons.css" />
    <link rel="stylesheet" href="assets/vendor/fonts/fontawesome.css" />
    <link rel="stylesheet" href="assets/vendor/fonts/flag-icons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="assets/vendor/css/rtl/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="assets/vendor/css/rtl/theme-semi-dark.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="assets/css/demo.css" />
    
    <!-- Vendors CSS -->
    <link rel="stylesheet" href="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
    <link rel="stylesheet" href="assets/vendor/libs/typeahead-js/typeahead.css" /> 
    <!-- Vendor -->
<link rel="stylesheet" href="assets/vendor/libs/%40form-validation/umd/styles/index.min.css" />

    <!-- Page CSS -->
    <!-- Page -->
<link rel="stylesheet" href="assets/vendor/css/pages/page-auth.css">

    <!-- Helpers -->
    <script src="assets/vendor/js/helpers.js"></script>
    <script src="assets/vendor/js/template-customizer.js"></script>
    <script src="assets/js/config.js"></script>

      <script src="include/sweetalert2.all.min.js"></script>
<!-- Optional: include a polyfill for ES6 Promises for IE11 -->
<script src="https://cdn.jsdelivr.net/npm/promise-polyfill"></script>
<!-- Popup Script -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <!--  -->

     <!--  -->
    <!-- CK Editors -->
    <script src="https://cdn.ckeditor.com/4.8.0/full-all/ckeditor.js"></script>
    
</head>

<body>


  <!-- Content -->

<div class="container-xxl">
  <div class="authentication-wrapper authentication-basic container-p-y">
    <div class="authentication-inner py-4">

      <!-- Register -->
      <div class="card">
        <div class="card-body">
          <!-- Logo -->
          <div class="app-brand justify-content-center">
            <a href="index.php" class="app-brand-link gap-2">
    
              <span class="app-brand-text demo h3 mb-0 fw-bold">Create a New Account</span>
            </a>
          </div>
          <!-- /Logo -->
          <form id="formAuthentication_n" class="mb-3" action="" method="POST">
            <div class="col-md-12" style="margin-top: 20px;">
                              <strong>Full Name:</strong>
                              <input type="text" class="form-control" name="firstname" required="" placeholder="Enter Full Name..." style="border-radius: 0rem;" />
                            </div>
    
           <div class="col-md-12" style="margin-top: 20px;">
                              <strong>Email ID:</strong>
                              <input type="email" class="form-control" name="email" required="" placeholder="Enter Email ID..." style="border-radius: 0rem;" />
                            </div>

                            <div class="col-md-12" style="margin-top: 20px;">
                              <strong>Emp ID.</strong>
                              <input type="text" class="form-control" minlength="1" maxlength="4" name="username" required="" placeholder="Enter Emp ID..." style="border-radius: 0rem;" />
                            </div>

                             <div class="col-md-12" style="margin-top: 20px;">
                              <strong>Department:</strong>
                             <select class="form-control" name="department_id" required="" style="border-radius: 0rem;">
                              <option value="">---Select Department---</option>
                               <?php
           
 $qry="select * from department";
 $run=mysqli_query($conn,$qry);
 while($row=mysqli_fetch_array($run))
 {
  ?>
<option value="<?php echo $row["id"]; ?>"><?php echo $row["Department"]; ?></option>
 <?php
}
  ?>
                             </select>

                            </div>



                           
                           <div class="col-md-12" style="margin-top: 20px;">
                              <strong>User Role :</strong>
                              <select class="form-control" name="type" required style="border-radius: 0rem;">
                                <option value="3">User</option>
                              </select>
                            </div>


                             <div class="col-md-12" style="margin-top: 20px;">
                              <strong>Designation:</strong>
                              <select class="form-control" name="designation_id" required="" style="border-radius: 0rem;">
                                <option value="">---Select Designation---</option>
                                <?php
           
 $qry="select * from designation";
 $run=mysqli_query($conn,$qry);
 while($row=mysqli_fetch_array($run))
 {
  ?>
<option value="<?php echo $row["id"]; ?>"><?php echo $row["Designation"]; ?></option>
 <?php
}
  ?>
                              </select>

                            </div>

                              <div class="col-md-12" style="margin-top: 20px;">
                              <strong>Password:</strong>
                              <input type="password" class="form-control" name="password" required="" placeholder="Enter Password..." style="border-radius: 0rem;" />
                            </div>

   

            <div class="mb-3 mt-3">
              <input type="submit" name="signin" value="Submit" class="btn btn-primary d-grid w-100">
              <!-- <button class="btn btn-primary d-grid w-100" name="signin" type="submit">Sign in</button> -->
            </div>
            <div class="mb-3 text-center">
              <p><a href="index.php">Log in</a> if you already have an account</p>
            </div>
          </form>

          <div class="divider my-4">
            <div class="divider-text">
          Powered By : <a href="">ABC</a></div>
          </div>

        </div>
      </div>
      <!-- /Register -->
    </div>
  </div>
</div>

<!-- / Content -->



<?php 
      if(isset($_POST['signin']))
      {
        $type=$_POST['type'];
        $username=$_POST['username'];
        $firstname=$_POST['firstname'];
        $lastname='';
        $email=$_POST['email'];
        $password=md5($_POST['password']);
        $designation_id=$_POST['designation_id'];
        $department_id=$_POST['department_id'];

   $qry="select * from users where username='$username'";
      $res=mysqli_query($conn,$qry);
      $data=mysqli_fetch_assoc($res);

      if($data==true)
      {
        ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'warning',
                                                      title: 'Emp ID Already Registered',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Sign-up.php";
                                                        });
                                                                </script>
      <?php
      }
      else
      {


   $qry="select * from users where email='$email'";
      $res=mysqli_query($conn,$qry);
      $data=mysqli_fetch_assoc($res);


      if($data==true)
      {
        ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'warning',
                                                      title: 'Email ID Already Registered',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Sign-up.php";
                                                        });
                                                                </script>
      <?php

      }
      else
      {
        $sql = "INSERT INTO `users` (`username`, `firstname`, `lastname`, `email`, `password`, `type`, `designation_id`, `department_id`, `avatar`,`date_created`,`status`) VALUES ('$username', '$firstname', '$lastname', '$email', '$password', '$type', '$designation_id', '$department_id', '',CURRENT_TIMESTAMP,'0')";

 $sqll=mysqli_query($conn,$sql);

 if($sqll==true)
 {
   ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'success',
                                                      title: 'Registration Submit Successful',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "index.php";
                                                        });
                                                                </script>
      <?php
 }
 else{
  ?>
             <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'error',
                                                      title: 'Error!!',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "index.php";
                                                        });
                                                                </script>

      <?php
 }
      }



      }


}

            ?>  


  
  <script src="assets/vendor/libs/jquery/jquery.js"></script>
  <script src="assets/vendor/libs/popper/popper.js"></script>
  <script src="assets/vendor/js/bootstrap.js"></script>
  <script src="assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
  <script src="assets/vendor/libs/hammer/hammer.js"></script>
  <script src="assets/vendor/libs/i18n/i18n.js"></script>
  <script src="assets/vendor/libs/typeahead-js/typeahead.js"></script>
  <script src="assets/vendor/js/menu.js"></script>
  
  <!-- endbuild -->

  <!-- Vendors JS -->
  <script src="assets/vendor/libs/%40form-validation/umd/bundle/popular.min.js"></script>
<script src="assets/vendor/libs/%40form-validation/umd/plugin-bootstrap5/index.min.js"></script>
<script src="assets/vendor/libs/%40form-validation/umd/plugin-auto-focus/index.min.js"></script>

  <!-- Main JS -->
  <script src="assets/js/main.js"></script>
  

  <!-- Page JS -->
  <script src="assets/js/pages-auth.js"></script>
  
</body>
</html>

