<?php include "Head.php"; ?>

<body>

  
  <!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar  ">
  <div class="layout-container">


<!-- Menu -->
<?php include "Menu.php"; ?>
<!-- / Menu -->


    <!-- Layout container -->
    <div class="layout-page">

<!-- Navbar -->
<?php include "Top-Header.php"; ?>  
<!-- / Navbar -->

      
      <!-- Content wrapper -->
      <div class="content-wrapper">

        <!-- Content -->
        
          <div class="container-xxl flex-grow-1 container-p-y">
            
            
<h4 class="py-3 breadcrumb-wrapper mb-4">
  <span class="text-muted fw-light">Welcome : </span> 
  <?php 
  // if ($user_type == "1") {
  //     echo "Super Admin";
  // } elseif ($user_type == "2") {
  //     echo "Admin";
  // } else {
  //     echo "User";
  // } 
  echo $user_firstname;
  ?>
</h4>

<!-- Card Border Shadow -->
<div class="row">
  <div class="col-sm-6 col-lg-3 mb-4">
  <a href="Ticket-Raise-List.php?ticket_status=1">
      <div class="card card-border-shadow-primary h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2 pb-1">
          <div class="avatar me-2">
            <span class="avatar-initial rounded bg-label-primary"><i class="bx bxs-truck"></i></span>
          </div>
          <h4 class="ms-1 mb-0"><?php

          $where='';
           if($user_type=='1')
           {
              $where="where status='1'";
           }
           elseif($user_type=='2') {
             $where="where status='1' and assignee='$user_id'";
           } else {
             $where="where status='1' and user_id='$user_id'";
           }
           
           $sql = "select IFNULL(count(*),0) as board from ticket $where";

          $result = mysqli_query($conn, $sql);
          $data = mysqli_fetch_assoc($result);
          $d = $data["board"];
          if ($d == "") {
              echo "0";
          } else {
              echo $d;
          }
          ?></h4>
        </div>
        <p class="mb-1">Open Ticket</p>
        
      </div>
    </div>
  </a>
  </div>
  <div class="col-sm-6 col-lg-3 mb-4">
  <a href="Ticket-Raise-List.php?ticket_status=3">
      <div class="card card-border-shadow-warning h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2 pb-1">
          <div class="avatar me-2">
            <span class="avatar-initial rounded bg-label-warning"><i class='bx bx-error'></i></span>
          </div>
          <h4 class="ms-1 mb-0"><?php

          $where='';
           if($user_type=='1')
           {
              $where="where status='3'";
           }
           elseif($user_type=='2') {
             $where="where status='3' and assignee='$user_id'";
           } else {
             $where="where status='3' and user_id='$user_id'";
           }
           
           $sql = "select IFNULL(count(*),0) as board from ticket $where";

          $result = mysqli_query($conn, $sql);
          $data = mysqli_fetch_assoc($result);
          $d = $data["board"];
          if ($d == "") {
              echo "0";
          } else {
              echo $d;
          }
          ?></h4>
        </div>
        <p class="mb-1">Resolve Ticket</p>
      </div>
    </div>
  </a>
  </div>
  <div class="col-sm-6 col-lg-3 mb-4">
    <a href="Ticket-Raise-List.php?ticket_status=4">
      <div class="card card-border-shadow-danger h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2 pb-1">
          <div class="avatar me-2">
            <span class="avatar-initial rounded bg-label-danger"><i class='bx bx-git-repo-forked'></i></span>
          </div>
          <h4 class="ms-1 mb-0"><?php

          $where='';
           if($user_type=='1')
           {
              $where="where status='4'";
           }
           elseif($user_type=='2') {
             $where="where status='4' and assignee='$user_id'";
           } else {
             $where="where status='4' and user_id='$user_id'";
           }
           
           $sql = "select IFNULL(count(*),0) as board from ticket $where";

          $result = mysqli_query($conn, $sql);
          $data = mysqli_fetch_assoc($result);
          $d = $data["board"];
          if ($d == "") {
              echo "0";
          } else {
              echo $d;
          }
          ?></h4>
        </div>
        <p class="mb-1">Close Ticket</p>
      </div>
    </div>
    </a>
  </div>
  <div class="col-sm-6 col-lg-3 mb-4">
    <a href="Ticket-Raise-List.php?ticket_status=2">
      <div class="card card-border-shadow-info h-100">
      <div class="card-body">
        <div class="d-flex align-items-center mb-2 pb-1">
          <div class="avatar me-2">
            <span class="avatar-initial rounded bg-label-info"><i class='bx bx-time-five'></i></span>
          </div>
          <h4 class="ms-1 mb-0"><?php

          $where='';
           if($user_type=='1')
           {
              $where="where status='2'";
           }
           elseif($user_type=='2') {
             $where="where status='2' and assignee='$user_id'";
           } else {
             $where="where status='2' and user_id='$user_id'";
           }
           
           $sql = "select IFNULL(count(*),0) as board from ticket $where";

          $result = mysqli_query($conn, $sql);
          $data = mysqli_fetch_assoc($result);
          $d = $data["board"];
          if ($d == "") {
              echo "0";
          } else {
              echo $d;
          }
          ?></h4>
        </div>
        <p class="mb-1">Pending Ticket</p>
      </div>
    </div>
    </a>
  </div>
</div>

                   <?php if (
                       isset($_GET["type"]) &&
                       $_GET["type"] !== "" &&
                       isset($_GET["id"]) &&
                       $_GET["id"] > 0
                   ) {
                       $type = $_GET["type"];
                       $id = $_GET["id"];
                       if ($type == "0" || $type == "1") {
                           $status = "1";
                           if ($type == "1") {
                               $status = "0";
                           }
                           $sqll = "update equipment set status='$status' where id='$id'";
                           mysqli_query($conn, $sqll);
                       }
                   } ?>
            <div class="card" style="border-radius: 0px;">
              <div style="border: 2px solid #182535; padding: 12px">
              <div class="bg-dark text-white" style="padding:5px;font-size: 18px;text-align: center;font-weight: bold;">
             Top 10 Ticket Raise List</div>
             <div class="card-body">
                 <input type="search" id="filter"  data-table="order-table" placeholder="Filtrer....." class="form-control light-table-filter" title="Type in a name">
                 <br>
            <!-- /.box-header -->
            <div class="box-body table-responsive">
              <table id="example" class="table table-responsive table-bordered table-hover order-table">
                <thead>
                <tr>
                  <?php if ($user_type == "1" || $user_type == "2") { ?>
                     <th>Username</th>
                     <?php } ?>
                  <th>equipment_type</th>
                  <th>ticket_description</th>
                  <th>ticket_raisedate</th>
                   <?php if ($user_type == "1") { ?>
                     <th>assignee</th>
                     <?php } ?>
                  
                  <!-- <th>date_added</th> -->
                  <th>date_updated</th> 
                    <?php if ($user_type == "3" || $user_type == "1") { ?>
                     <th>status</th>
                     <?php } ?>

                   <?php if ($user_type == "2") { ?>
                     <th>status</th>
                     <?php } ?>           
                  <?php if ($user_type == "1" || $user_type == "3") { ?>
                    <!-- <th class="text-center">Action</th> -->
                    <?php } ?>
                </tr>
                </thead>
                <tbody>
                         
     
                 <?php
                 $wheree = "";
               

                         if ($user_type == "3") {
                     $wheree = "where user_id='$user_id' ORDER BY id DESC limit 10";
                 } elseif ($user_type == "2") {
                     $wheree = "where assignee='$user_id' ORDER BY id DESC limit 10";
                 } elseif ($user_type == "1") {
                     $wheree = "ORDER BY id DESC limit 10 ";
                 }



              $qry = "select * from ticket $wheree";
                 $run_n = mysqli_query($conn,$qry);

                 while ($var = mysqli_fetch_assoc($run_n)) { ?>
            <tr>
              <?php if ($user_type == "1" || $user_type == "2") { ?>
                     <td><?php
                     $user_idd = $var["user_id"];
                     $qryy = " select * from users where id='$user_idd' ORDER BY id DESC";
                     $runn = mysqli_query($conn, $qryy);
                     $varr = mysqli_fetch_assoc($runn);
                     echo $firstname = $varr["firstname"];
                     ?></td>
                     <?php } ?>
            <td><?php 
            $equ_id=$var["equipment_id"];
               $qryy_equ = " select * from equipment where id='$equ_id' ORDER BY id DESC";
                     $runn_equ = mysqli_query($conn, $qryy_equ);
                     $varr_equ = mysqli_fetch_assoc($runn_equ);
                     echo $equipment_type = $varr_equ["equipment_type"];
             ?></td>
            <td><?= $var["ticket_description"] ?></td>
            <td><?= $var["ticket_raisedate"] ?></td>
              <?php if ($user_type == "1") { ?>
                     <td>

                             <?php 
                                        if($var['assignee'] == 0){
                                           ?>

                                           <button type="button" class="btn btn-default btn-sm btn-flat border-info wave-effect text-info dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Click To Assigne
                                             </button>

                                           <?php
                                       }
              else
              {
                ?>
                <button type="button" class="btn btn-default btn-sm btn-flat border-info wave-effect text-info dropdown-toggle" data-toggle="dropdown" aria-expanded="true"><?php $user_idd=$var["assignee"];
                $qryy = " select * from users where id='$user_idd' ORDER BY id DESC";
                     $runn = mysqli_query($conn, $qryy);
                     $varr = mysqli_fetch_assoc($runn);
                     echo $firstname = $varr["firstname"];

                 ?>                                          </button>
                <?php

              }
                                        ?>
                       
                            <div class="dropdown-menu" style="">
                                   <a class="dropdown-item view_project" href="Ticket-Raise-List.php?id=<?php echo '0' ;?>&&ticket_id=<?=$var["id"]?>" data-id="<?php echo $var['id'] ?>">Reset</a>
                              <div class="dropdown-divider"></div> 

 <?php
                                $qry = "select * from users where type='2' and status='1'";
                                $run = mysqli_query($conn, $qry);
                                while ($row = mysqli_fetch_array($run)) 
                                    { 
                                        ?>
                                 <a class="dropdown-item view_project" href="Ticket-Raise-List.php?id=<?php echo $row['id'] ?>&&ticket_id=<?=$var["id"]?>" data-id="<?php echo $var['id'] ?>"><?php echo $row['firstname'] ?></a>
                              <div class="dropdown-divider"></div> 
                                   <?php 
                               }
                                ?>
                             

                       
                          
                            </div>
</td>

                     <?php } ?>
            <!-- <td><?= $var["date_added"] ?></td> -->
            <td><?= $var["date_updated"] ?></td> 
          
                    <?php if ($user_type == "3" || $user_type == "1") { ?>
                     <td>  <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal<?php echo $var[
                         "id"
                     ]; ?>ticket_status">

                     <?php 

                      if ($var["status"] == "1") { ?>
                  <b class="">Open</b>
                  <?php 
                  } 
                  elseif ($var["status"] == "2") 
                    { 
                    ?>
                  <b class="">Pending</b>
                  <?php 
                   }

                   elseif ($var["status"] == "3") 
                    { 
                    ?>
                  <b class="">Resolve</b>
                  <?php 
                   }


              else { 
                ?>
                  <b class="">Comfirm</b>
                  <?php 
              }

                      ?>


                 </button>

                                     <div class="modal" id="myModal<?php echo $var[
                                         "id"
                                     ]; ?>ticket_status">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Status Update </h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       <div class="row">
         <div class="col-md-8">
              <?php
              $ticket_user_id = $var["user_id"];
              $ticket_id = $var["id"];
              $ticket_equipment_id = $var["equipment_id"];
              ?>
     <div class="card-body" >
       <div class="table-responsive" style="height: 250px;">
               <table class="table table-bordered table-responsive order-table">
    <thead>
      <tr>
        <th>User ID</th>
        <th>Comment</th>
        <th>Status</th>
        <th>Update Date</th>
      </tr>
    </thead>
    <tbody>
      <?php
    
      $qry_ticket_status = " select * from ticket_status where ticket_id='$ticket_id' ORDER BY id DESC";
      $run_ticket_status = mysqli_query($conn, $qry_ticket_status);

      while ($var_ticket_status = mysqli_fetch_assoc($run_ticket_status)) { ?>
            <tr>
                <td><?php 
                         $user_idd=$var_ticket_status["it_admin_id"];
                           $qryy = " select * from users where id='$user_idd' ORDER BY id DESC";
                     $runn = mysqli_query($conn, $qryy);
                     $varr = mysqli_fetch_assoc($runn);
                     echo $firstname = $varr["firstname"];
                          ?></td>
            <td><?= $var_ticket_status["ticket_comment"] ?></td>
            <td><?php
           $var_ticket_statuss = $var_ticket_status["status"];

            if ($var_ticket_statuss == "1") { ?>
                  <b class="text-danger">Open</b>
                  <?php 
                  } 
                  elseif ($var_ticket_statuss == "2") 
                    { 
                    ?>
                  <b class="text-primary">Pending</b>
                  <?php 
                   }

                   elseif ($var_ticket_statuss == "3") 
                    { 
                    ?>
                  <b class="text-success">Resolve</b>
                  <?php 
                   }


              else { 
                ?>
                  <b class="text-success">Comfirm</b>
                  <?php 
              }
            ?></td>
            <td><?= $var_ticket_status["dateadded"] ?></td>
            </tr>
            <?php }
      ?>
              
    </tbody>
  </table>
       </div>
     </div>
         </div>
         <div class="col-md-4">
             <?php 
                 if($user_type=='1')
                 {

                 }
                 else
                 {
                  ?>
          <form action="" method="POST">
                
<?php 
 $qry_ticket_status_comfrim_check = " select * from ticket where id='$ticket_id' ORDER BY id DESC";
      $run_ticket_status_comfrim_check = mysqli_query($conn, $qry_ticket_status_comfrim_check);
   $var_ticket_status_comfrim_check = mysqli_fetch_assoc($run_ticket_status_comfrim_check);
   $comfrim_check_status=$var_ticket_status_comfrim_check['status'];
   $comfrim_check_user_id=$var_ticket_status_comfrim_check['user_id'];
   $qryy = " select * from users where id='$comfrim_check_user_id' ORDER BY id DESC";
                     $runn = mysqli_query($conn, $qryy);
                     $varr = mysqli_fetch_assoc($runn);
                     $firstname = $varr["firstname"];
if($comfrim_check_status == '4')
{
    ?>
      <div class="form-group mt-5">
    <center><b style="color: green;">Status Confirm By <?=$firstname?></b></center>
  </div>
    <?php

}
else
{

    ?>

     <?php
              $ticket_user_id = $var["user_id"];
              $ticket_id = $var["id"];
              $ticket_equipment_id = $var["equipment_id"];
              ?>

    <input type="hidden" name="ticket_user_id" value="<?= $ticket_user_id ?>">
        <input type="hidden" name="ticket_id" value="<?= $ticket_id ?>">
        <input type="hidden" name="ticket_equipment_id" value="<?= $ticket_equipment_id ?>">
        <div class="form-group">
          <strong>Status Comment:</strong>
          <textarea class="form-control" name="ticket_comment" id="" cols="30" rows="5"></textarea>
        </div>
        <div class="form-group">
                     <select class="form-control" name="status" required="" style="border-radius: 0rem;">
                              <option value="">---Select Status---</option>
                              <option value="2">Pending</option>
                              <option value="4">Confirm</option>
                             </select>
        </div>
      <div class="form-group">
    <center><input type="submit" name="staff_comment_submit" class="bt btn-primary btn-sm"></center>
  </div>
    <?php

}
 ?>

             </form>
                  <?php
                 }
              ?>
         </div>
       </div>
      </div>

      

      <!-- Modal footer -->
      

    </div>
  </div>
</div>

                     </td>
      
                     <?php } ?>
             <?php if ($user_type == "2") { ?>
                     <td> <?php
                     $status = $var["status"];
                     if ($status == "1") { ?>
                      <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#myModal<?php echo $var[
                          "id"
                      ]; ?>">Open</button>
                      <?php } elseif ($status == "2") { ?>
                      <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModal<?php echo $var[
                          "id"
                      ]; ?>">Pending</button>
                      <?php }

                      elseif ($status == "3") { ?>
                    <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModal<?php echo $var[
                          "id"
                      ]; ?>">Resolve</button>
                      <?php }

                       else { ?>
                      <button type="button" class="btn btn-success btn-sm" data-toggle="modal" data-target="#myModal<?php echo $var[
                          "id"
                      ]; ?>">Confirm</button>
                      <?php }
                     ?>


<!-- The Modal -->
<div class="modal" id="myModal<?php echo $var["id"]; ?>">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Status Update </h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
       <div class="row">
         <div class="col-md-6">
              <?php
              $ticket_user_id = $var["user_id"];
              $ticket_id = $var["id"];
              $ticket_equipment_id = $var["equipment_id"];
              ?>
       <form action="" method="POST">
        <input type="hidden" name="ticket_user_id" value="<?= $ticket_user_id ?>">
        <input type="hidden" name="ticket_id" value="<?= $ticket_id ?>">
        <input type="hidden" name="ticket_equipment_id" value="<?= $ticket_equipment_id ?>">
        <div class="col-md-12">
          <strong>Status Comment:</strong>
          <textarea class="form-control" name="ticket_comment" id="" cols="30" rows="5"></textarea>
        </div>
         <div class="col-md-12" style="margin-top: 20px;">
                              <strong>Update Status:</strong>
                             <select class="form-control" name="status" required="" style="border-radius: 0rem;">
                              <option value="">---Select Status---</option>
                              <option value="1">Open</option>
                              <option value="2">Pending</option>
                              <option value="3">Resolve</option>
                             </select>

                             <?php 
 $qry_ticket_status_comfrim_check = " select * from ticket where id='$ticket_id' ORDER BY id DESC";
      $run_ticket_status_comfrim_check = mysqli_query($conn, $qry_ticket_status_comfrim_check);
   $var_ticket_status_comfrim_check = mysqli_fetch_assoc($run_ticket_status_comfrim_check);
   $comfrim_check_status=$var_ticket_status_comfrim_check['status'];
   $comfrim_check_user_id=$var_ticket_status_comfrim_check['user_id'];
   $qryy = " select * from users where id='$comfrim_check_user_id' ORDER BY id DESC";
                     $runn = mysqli_query($conn, $qryy);
                     $varr = mysqli_fetch_assoc($runn);
                     $firstname = $varr["firstname"];
if($comfrim_check_status == '4')
{
    ?>
      <div class="form-group">
    <center><b style="color: green;">Status Confirm By <?=$firstname?></b></center>
  </div>
    <?php

}
else
{

    ?>
      <div class="form-group">
    <center><input type="submit" value="Update" name="tciket_status_update" class="btn btn-primary mt-5"></center>
  </div>
    <?php

}
 ?>

                            </div>
       </form>
         </div>
         <div class="col-md-6">
                          <table class="table table-bordered table-responsive order-table">
    <thead>
      <tr>
        <th>Comment</th>
        <th>Status</th>
        <th>Update Date</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $qry_ticket_status = " select * from ticket_status where ticket_id='$ticket_id' ORDER BY id DESC";
      $run_ticket_status = mysqli_query($conn, $qry_ticket_status);

      while ($var_ticket_status = mysqli_fetch_assoc($run_ticket_status)) { ?>
            <tr>
            <td><?= $var_ticket_status["ticket_comment"] ?></td>
            <td><?php
           $var_ticket_statuss = $var_ticket_status["status"];

            if ($var_ticket_statuss == "1") { ?>
                  <b class="text-danger">Open</b>
                  <?php 
                  } 
                  elseif ($var_ticket_statuss == "2") 
                    { 
                    ?>
                  <b class="text-primary">Pending</b>
                  <?php 
                   }

                   elseif ($var_ticket_statuss == "3") 
                    { 
                    ?>
                  <b class="text-success">Resolve</b>
                  <?php 
                   }


              else { 
                ?>
                  <b class="text-success">Confirm</b>
                  <?php 
              }
            ?></td>
            <td><?= $var_ticket_status["dateadded"] ?></td>
            </tr>
            <?php }
      ?>
              
    </tbody>
  </table>
         </div>
       </div>
      </div>

      

      <!-- Modal footer -->
      

    </div>
  </div>
</div>
                 </td>


                     <?php } ?>
            
            <?php if ($user_type == "1" || $user_type == "3") { ?>
              <!-- <td> -->
             <!--  <center><a href="Ticket-Raise-List.php?idd=<?php echo $var[
                  "id"
              ]; ?>" onclick="return confirm('Are You Sure Delete?')" class="btn btn-sm btn-danger">Delete</a></center> -->
            <!-- </td> -->
            <?php } ?>
            
          
            </tr>
            <?php }
                 ?>
                </tbody>
           
              </table>
            </div>
             </div>
            </div>
          </div>

          </div>
          <!-- / Content -->   

          
          <div class="content-backdrop fade"></div>
        </div></div>


          
<!-- IT Admin Status Change Code -->
<?php if (isset($_POST["tciket_status_update"])) {
    $ticket_user_id = $_POST["ticket_user_id"];
    $ticket_id = $_POST["ticket_id"];
    $ticket_equipment_id = $_POST["ticket_equipment_id"];
    @$assignee_id = $_POST["assignee_id"];
    $ticket_comment = $_POST["ticket_comment"];
    $status = $_POST["status"];

    $sql = "update ticket set status='$status' , date_updated= CURRENT_TIMESTAMP where id='$ticket_id'and equipment_id='$ticket_equipment_id' and user_id='$ticket_user_id'";

    $sql_inr = "INSERT INTO `ticket_status` (`it_admin_id`, `ticket_id`, `ticket_comment`, `dateadded`, `status`) VALUES ('$user_id','$ticket_id', '$ticket_comment', current_timestamp(), '$status')";

    $sql_ticket_status = mysqli_query($conn, $sql_inr);

    $sqll = mysqli_query($conn, $sql);

    if ($sqll == true) { ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'success',
                                                      title: 'Status Update Successfully',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Dashboard.php";
                                                        });
                                                                </script>
      <?php } else { ?>
             <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'error',
                                                      title: 'Error!!',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Dashboard.php";
                                                        });
                                                                </script>

      <?php }
} ?>     
<!-- IT Admin Status End -->
          
<!-- Delete Query ALl Tabel -->


          <?php if (isset($_GET["idd"])) {
              $idd = $_GET["idd"];
              $result = $conn->query("DELETE FROM ticket WHERE id='$idd'");

              if ($result) { ?>
            <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'success',
                                                      title: 'Delete Successfull',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Dashboard.php";
                                                        });
                                                                </script>
             <?php } else { ?>
              <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'error',
                                                      title: 'Not Delete',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Dashboard.php";
                                                        });
                                                                </script>
                  <?php }
          } ?>
  


  <!-- Staff Comment And Satus Update -->
  <?php if (isset($_POST["staff_comment_submit"])) {
    $ticket_user_id = $_POST["ticket_user_id"];
    $ticket_id = $_POST["ticket_id"];
    $ticket_comment = $_POST["ticket_comment"];
    $status = $_POST["status"];

    $sql = "update ticket set status='$status' , date_updated= CURRENT_TIMESTAMP where id='$ticket_id'and user_id='$ticket_user_id'";

     $sql_inr = "INSERT INTO `ticket_status` (`it_admin_id`, `ticket_id`, `ticket_comment`, `dateadded`, `status`) VALUES ('$user_id','$ticket_id', '$ticket_comment', current_timestamp(), '$status')";

    $sql_ticket_status = mysqli_query($conn, $sql_inr);

    $sqll = mysqli_query($conn, $sql);

    if ($sqll == true) { ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'success',
                                                      title: 'Status Update Successfully',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Dashboard.php";
                                                        });
                                                                </script>
      <?php } else { ?>
             <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'error',
                                                      title: 'Error!!',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Dashboard.php";
                                                        });
                                                                </script>

      <?php }
} ?>  


          
          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->

     

<!-- Footer -->
<?php include "Footer.php"; ?>
