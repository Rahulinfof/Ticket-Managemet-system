<!-- Menu -->

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">

  
  <div class="app-brand demo ">
    <a href="Dashboard.php" class="app-brand-link">
  
      <span class="app-brand-text demo menu-text fw-bold ms-2">  <?php
  if($user_type=='1')
  {
    echo 'Super Admin';
  }
  elseif ($user_type=='2') {
    echo 'IT Admin';
  }
  else{
    echo 'User Panel';
  }
  ?> </span>
    </a>

   <!--  <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto">
      <i class="bx menu-toggle-icon d-none d-xl-block fs-4 align-middle"></i>
      <i class="bx bx-x d-block d-xl-none bx-sm align-middle"></i>
    </a> -->
    
  </div>

  
  <div class="menu-divider mt-0  ">
  </div>

  <div class="menu-inner-shadow"></div>

  
  
  <ul class="menu-inner py-1">
    <!-- Dashboards -->
     <li class="menu-item">
      <a href="Dashboard.php" class="menu-link">
        <i class="menu-icon tf-icons bx bx-home-circle"></i>
        <div data-i18n="Dashboard">Dashboard</div>
      </a>
    </li>




    
<!-- Equipment -->
    <li class="menu-item">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bx-layout"></i>
        <div data-i18n="Equipment">Equipment</div>
      </a>

      <ul class="menu-sub">

        <li class="menu-item">
          <a href="Add-Equipment.php" class="menu-link">
            <div data-i18n="Add Equipment">Add Equipment</div>
          </a>
        </li>
        <li class="menu-item">
          <a href="Equipment-List.php" class="menu-link">
            <div data-i18n="Equipment List">Equipment List</div>
          </a>
        </li>
        
      </ul>
    </li>



  <?php 
       if($user_type=='1')
        {
          ?>
    <!-- User -->
    <li class="menu-item">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bx-layout"></i>
        <div data-i18n="User">User</div>
      </a>

      <ul class="menu-sub">

        <li class="menu-item">
          <a href="Add-Users.php" class="menu-link">
            <div data-i18n="Add User">Add User</div>
          </a>
        </li>
        <li class="menu-item">
          <a href="User-List.php" class="menu-link">
            <div data-i18n="User List">User List</div>
          </a>
        </li>
        
      </ul>
    </li>
    <?php
        }

         ?>



   <!-- Ticket -->
    <li class="menu-item">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons bx bx-layout"></i>
        <div data-i18n="Ticket">Ticket</div>
      </a>

      <ul class="menu-sub">

        <li class="menu-item">
          <a href="Ticket-Raise.php" class="menu-link">
            <div data-i18n="Add Ticket">Add Ticket</div>
          </a>
        </li>
        <li class="menu-item">
          <a href="Ticket-Raise-List.php" class="menu-link">
            <div data-i18n="Ticket List">Ticket List</div>
          </a>
        </li>
        
      </ul>
    </li>


  <li class="menu-item">
      <a href="Profile-Update.php" class="menu-link">
        <i class="menu-icon tf-icons bx bx-layout"></i>
        <div data-i18n="Profile Update">Profile Update</div>
      </a>
    </li>
    
    
    <!-- Misc -->
    <li class="menu-header small text-uppercase"><span class="menu-header-text" data-i18n="Other Menu">Other Menu</span></li>
    <li class="menu-item">
      <a href="logout.php" class="menu-link">
        <i class="menu-icon tf-icons bx bx-power-off"></i>
        <div data-i18n="Logout">Logout</div>
      </a>
    </li>
  
  </ul>
  
  

</aside>
<!-- / Menu -->
