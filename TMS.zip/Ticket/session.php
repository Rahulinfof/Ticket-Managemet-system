<?php
include('conn/conn.php');
Session_start();
if($_SESSION['username']==true)
{

	 $username=$_SESSION['username'];
          $type=$_SESSION['type'];

            $username=$_SESSION['username'];
   $qry="select * from users where username='$username' and type='$type'";
   $res=mysqli_query($conn,$qry);
      $data=mysqli_fetch_assoc($res); 
      $user_id=$data['id'];
      $user_type=$data['type'];
      $avatar=$data['avatar'];
      $user_firstname=$data['firstname'];
      
// $qry = "SELECT * FROM admin WHERE username='$username' and type='$type'";

//     $run=mysqli_query($conn,$qry);
//     $row=mysqli_num_rows($run);
//      $data=mysqli_fetch_assoc($run);
//      $username=$data['username'];
//      $password=$data['password'];
     // $type=$data['type'];
     // $ccode='0001';
}
else
{
Header('location:index.php');
}
?>