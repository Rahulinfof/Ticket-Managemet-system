<?php include "Head.php"; ?>

<body>

  
  <!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar  ">
  <div class="layout-container">




<!-- Menu -->
<?php include "Menu.php"; ?>
<!-- / Menu -->

    

    <!-- Layout container -->
    <div class="layout-page">
      
      



<!-- Navbar -->
<?php include "Top-Header.php"; ?>  
<!-- / Navbar -->

      
      <!-- Content wrapper -->
      <div class="content-wrapper">

        <!-- Content -->
        
          <div class="container-xxl flex-grow-1 container-p-y">
    
    
<?php
// Ticket Name
$qry_user_details = " select * from users where id='$user_id'";
$run_user_details = mysqli_query($conn, $qry_user_details);
@$var_user_details = mysqli_fetch_assoc($run_user_details);
@$user_details_id = $var_user_details["id"];
@$user_details_name = $var_user_details["firstname"];
@$user_details_email = $var_user_details["email"];
@$user_details_password = $var_user_details["password"];
@$user_details_avatar = $var_user_details["avatar"];

// End Ticket Name
?>

            <div class="card mt-2" style="border-radius: 0px;">
             <div >

   
               <div class="card-body" style="border: 2px solid #182535; padding: 12px">
               <form id="reg_form" class="clearfix" name="reg_form" method="post" action="" enctype="multipart/form-data" autocomplete="off">
                 
                      <div class="bg-dark text-white" style="padding:5px;font-size: 18px;text-align: center;font-weight: bold;">Profile</div>
                    <div class="row" style="margin-bottom: 15px;">
                      <div class="col-md-12">
                        <div class="form-group">
                          <div class="row">
                          <div class="col-md-4"></div>
                             <div class="col-md-4">
                                 <div class="row">
                                     
                           <div class="col-md-12" style="margin-top: 20px;">
                              <strong>Full Name:</strong>
                              <input type="hidden" name="id" value="<?= $user_details_id ?>">
                              <input type="text" class="form-control" name="firstname" value="<?= $user_details_name ?>" required="" placeholder="Enter Full Name..." style="border-radius: 0rem;" />
                            </div>

                            <div class="col-md-12" style="margin-top: 20px;">
                              <strong>Email ID:</strong>
                              <input type="email" class="form-control" name="email" required="" value="<?= $user_details_email ?>" placeholder="Enter Email ID..." style="border-radius: 0rem;" />
                            </div>

                    
                           <div class="col-md-12" style="margin-top: 20px;">
                              <strong>Password:</strong>
                              <input type="text" class="form-control" name="password" required="" value="<?= $user_details_password ?>" placeholder="Enter Password..." style="border-radius: 0rem;" />
                            </div>
                            


                           



                             <div class="col-md-12" style="margin-top: 30px;">
          <div>
          <strong>Upload Image :</strong>
          <center> <br>
                      <input type="file" name="file" id="file1" onChange="readURL1(this);" accept="image/gif, image/jpeg, image/png , image/jpg" />
   <br><br><img class="" id="blah1" src="Profile/<?= $user_details_avatar ?>" class="img-responsive img-rounded" alt="" style="margin-bottom: 08px; width: 150px; height: 150px;" />
                    </center>
                                 <script>
  function readURL1(input) {

     var maxfilesize = 1024 ** 2,  // 1 Mb
      filesize    = input.files[0].size,
      warningel   = document.getElementById( 'lbError' );

  if ( filesize > maxfilesize )
  {
   Swal.fire({
                              icon: 'warning',
                              title: 'Please select a file less than 2MB.',
                              // text: 'Submit',
                              // footer: '
                              // < a href > Why do I have this issue ? < /a>'
                            }).then(function() {
                              // Redirect the user
                              // window.location.href = "register.php";
                            });
                            event.target.value = '';
  }
  else
  {
     

  } 


         var ext = event.target.files[0].type.split('/')[1];
  var extArray = ['png', 'jpeg']
 if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah1')
                    .attr('src', e.target.result)
                    .width(140)
                    .height(145);
            };
      reader.readAsDataURL(input.files[0]);
        }
  else
{
   
}


      
        var ext = event.target.files[0].type.split('/')[1];
  var extArray = ['png', 'jpeg']
  if(extArray.indexOf(ext) == -1){
    Swal.fire({
                              icon: 'warning',
                              title: 'Please Select Only Image File !!',
                              // text: 'Submit',
                              // footer: '
                              // < a href > Why do I have this issue ? < /a>'
                            }).then(function() {
                              // Redirect the user
                              // window.location.href = "register.php";
                            });
                            event.target.value = '';
  }
  else
{
   
}

    }


  
</script>
          
        </div>
        </div>
                                 </div>
                             </div>
   
                    
                          </div>
                        </div>
                      </div>
                      <br>
                      <div class="row" style="padding-top:5px; margin-bottom: 15px;">
                        <div class="col-md-12">
                       
                          <center><input type="submit" value="Submit" name="submit" class="btn btn-primary mt-5"></center>
                        </div>
                      </div>
                </form>
             </div>
            </div>

          </div>
          <!-- / Content -->

          
          

<?php if (isset($_POST["submit"])) {
    $id = $_POST["id"];
    $firstname = $_POST["firstname"];
    $email = $_POST["email"];
    $password = md5($_POST["password"]);

    $file = rand(1000, 100000) . "-" . $_FILES["file"]["name"];
    $file_loc = $_FILES["file"]["tmp_name"];
    $tempname = $_FILES["file"]["tmp_name"];

    $extension1 = pathinfo($_FILES["file"]["name"], PATHINFO_EXTENSION);

    if ($_FILES["file"]["error"] != 0) {
        $qryy = "update users set firstname='$firstname',email='$email',password='$password' where id='$id'";

        $sqll = mysqli_query($conn, $qryy);
        if ($sqll) { ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'success',
                                                      title: 'Update Successfull',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Profile-Update.php";
                                                        });
                                                                </script>
      <?php } else { ?>
             <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'error',
                                                      title: 'Error!!',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Profile-Update.php";
                                                        });
                                                                </script>

      <?php }
    } else {
        if (
            $extension1 == "jpg" ||
            $extension1 == "jpeg" ||
            $extension1 == "png"
        ) {
            $folder = "Profile/" . $file;
            move_uploaded_file($file_loc, $folder);

            $qryy = "update users set firstname='$firstname',email='$email',password='$password' ,avatar='$file' where id='$id'";

            $sqll = mysqli_query($conn, $qryy);
            if ($sqll) { ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'success',
                                                      title: 'Update Successfull',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Profile-Update.php";
                                                        });
                                                                </script>
      <?php } else { ?>
             <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'error',
                                                      title: 'Error!!',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Profile-Update.php";
                                                        });
                                                                </script>

      <?php }
        } else {
             ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'warning',
                                                      title: 'Please Select Only Image File !!',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Profile-Update.php";
                                                        });
                                                                </script>
      <?php
        }
    }
} ?>  

          
          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->

          
          

<!-- Footer -->
<?php include "Footer.php"; ?>
