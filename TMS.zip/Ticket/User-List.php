<?php include "Head.php"; ?>

<body>

  
  <!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar  ">
  <div class="layout-container">


<!-- Menu -->
<?php include "Menu.php"; ?>
<!-- / Menu -->

    

    <!-- Layout container -->
    <div class="layout-page">
      
                        <?php if (
                            isset($_GET["type"]) &&
                            $_GET["type"] !== "" &&
                            isset($_GET["id"]) &&
                            $_GET["id"] > 0
                        ) {
                            $type = $_GET["type"];
                            $id = $_GET["id"];
                            if ($type == "0" || $type == "1") {
                                $status = "1";
                                if ($type == "1") {
                                    $status = "0";
                                }
                                $sqll = "update users set status='$status' where id='$id'";
                                mysqli_query($conn, $sqll);
                            }
                        } ?> 



<!-- Navbar -->
<?php include "Top-Header.php"; ?>  
<!-- / Navbar -->

      
      <!-- Content wrapper -->
      <div class="content-wrapper">

        <!-- Content -->
        
          <div class="container-xxl flex-grow-1 container-p-y">
            
            <div class="card" style="border-radius: 0px;">
              <div style="border: 2px solid #182535; padding: 12px">
              <div class="bg-dark text-white" style="padding:5px;font-size: 18px;text-align: center;font-weight: bold;">User's List</div>
             <div class="card-body">
                 <input type="search" id="filter"  data-table="order-table" placeholder="Filtrer....." class="form-control light-table-filter" title="Type in a name">
                 <br>
            <!-- /.box-header -->
            <div class="box-body table-responsive">
              <table id="example" class="table table-responsive table-bordered table-hover order-table">
                <thead>
                <tr>
                  <th>username</th>
                  <th>firstname</th>
                  <th>email</th>
                  <th>password</th>
                  <th>user_role</th>
                  <th>designation_id</th>
                  <th>department_id</th>
                  <th>profile</th>
                  <th>status</th>
                    
                  <th colspan="2" class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                         
     
                 <?php
                 $qry = " select * from users ORDER BY id DESC";
                 $run = mysqli_query($conn, $qry);

                 while ($var = mysqli_fetch_assoc($run)) { ?>
            <tr>
            <td><?= $var["username"] ?></td>
            <td><?= $var["firstname"] ?></td>
            <td><?= $var["email"] ?></td>
            <td><?= $var["password"] ?></td>
            <td><?php
            $type = $var["type"];
            if ($type == "1") {
                echo "Super Admin";
            } elseif ($type == "2") {
                echo "IT Admin";
            } else {
                echo "User";
            }
            ?></td>
            <td> <?php
            $designation_id = $var["designation_id"];
            $qry_des = mysqli_query(
                $conn,
                "select * from designation where id='$designation_id'"
            );
            @$var_des = mysqli_fetch_assoc($qry_des);
            echo $var_des["Designation"];
            ?></td>
<td>
<?php
$department_id = $var["department_id"];
$qry_dep = mysqli_query($conn,"select * from department where id='$department_id'");
@$var_dep = mysqli_fetch_assoc($qry_dep);
echo $var_dep["Department"];
?>
</td>
<td><a target="_blank" href="Profile/<?= $var[
    "avatar"
] ?>"><img src="Profile/<?= $var[
    "avatar"
] ?>" alt="" style="max-width: 50px;"></a></td>
    <td>            <?php if ($var["status"] == "0") { ?>
                           <a href="?id=<?php echo $var[
                               "id"
                           ]; ?>&type=0"><label class="btn btn-danger btn-sm">Deactive</label></a>
                    <?php } else { ?>
                        <a href="?id=<?php echo $var[
                            "id"
                        ]; ?>&type=1"><label class="btn btn-success btn-sm blink">Active</label></a>
                    <?php } ?>   </td>

<td>
              <center><a href="User-Update.php?idd=<?php echo $var[
                  "id"
              ]; ?>" onclick="return confirm('Are You Sure Edit?')" class="btn btn-primary btn-sm">Edit</a></center>
            </td>
          
            <td>
              <center><a href="User-List.php?delete=<?php echo $var[
                  "id"
              ]; ?>&&banner=<?php echo $var[
    "avatar"
]; ?>" onclick="return confirm('Are You Sure Delete?')" class="btn btn-danger btn-sm">Delete</a></center>
            </td>
            </tr>
            <?php }
                 ?>
                </tbody>
           
              </table>
            </div>
             </div>
            </div>
          </div>

          </div>
          <!-- / Content -->   

          
          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->

          
          
<!-- Delete Query ALl Tabel -->


          <?php if (isset($_GET["delete"])) {
              $delete = $_GET["delete"];
              $banner = $_GET["banner"];
              $result = $conn->query("DELETE FROM users WHERE id='$delete'");

              if ($result) {
                  unlink("Profile/" . $banner); ?>
            <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'success',
                                                      title: 'Delete Successfull',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "User-List.php";
                                                        });
                                                                </script>
             <?php
              } else {
                   ?>
              <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'error',
                                                      title: 'Not Delete',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "User-List.php";
                                                        });
                                                                </script>
                  <?php
              }
          } ?>
  
<!-- Footer -->
<?php include "Footer.php"; ?>
