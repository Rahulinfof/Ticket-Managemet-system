<?php include "Head.php"; ?>

<body>

  
  <!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar  ">
  <div class="layout-container">

<!-- Menu -->
<?php include "Menu.php"; ?>
<!-- / Menu -->
    <!-- Layout container -->
    <div class="layout-page">

<!-- Navbar -->
<?php include "Top-Header.php"; ?>  
<!-- / Navbar -->

      
      <!-- Content wrapper -->
      <div class="content-wrapper">

        <!-- Content -->
        
          <div class="container-xxl flex-grow-1 container-p-y">

            <div class="card mt-2" style="border-radius: 0px;">
             <div >
               <div class="card-body" style="border: 2px solid #182535; padding: 12px">
               <form id="reg_form" class="clearfix" name="reg_form" method="post" action="" enctype="multipart/form-data" autocomplete="off">
                 
                      <div class="bg-dark text-white" style="padding:5px;font-size: 18px;text-align: center;font-weight: bold;">New User</div>
                    <div class="row" style="margin-bottom: 15px;">
                      <div class="col-md-12">
                        <div class="form-group">
                          <div class="row">
                          

                           <div class="col-md-6" style="margin-top: 20px;">
                              <strong>Full Name:</strong>
                              <input type="text" class="form-control" name="firstname" required="" placeholder="Enter Full Name..." style="border-radius: 0rem;" />
                            </div>

                            <div class="col-md-6" style="margin-top: 20px;">
                              <strong>Email ID:</strong>
                              <input type="email" class="form-control" name="email" required="" placeholder="Enter Email ID..." style="border-radius: 0rem;" />
                            </div>

                            <div class="col-md-6" style="margin-top: 20px;">
                              <strong>Emp ID.</strong>
                              <input type="text" class="form-control" name="username" required="" placeholder="Enter Emp ID..." minlength="1" maxlength="4" style="border-radius: 0rem;" />
                            </div>

                             <div class="col-md-6" style="margin-top: 20px;">
                              <strong>Department:</strong>
                             <select class="form-control" name="department_id" required="" style="border-radius: 0rem;">
                              <option value="">---Select Department---</option>
                               <?php
                               $qry = "select * from department";
                               $run = mysqli_query($conn, $qry);
                               while ($row = mysqli_fetch_array($run)) { ?>
                             <option value="<?php echo $row["id"]; ?>"><?php echo $row["Department"]; ?></option> <?php }
                               ?>
                             </select>

                            </div>



                           
                           <div class="col-md-6" style="margin-top: 20px;">
                              <strong>User Role :</strong>
                              <select class="form-control" name="type" required style="border-radius: 0rem;">
                                <option value="">---Select User Type---</option>
                                <option value="2">IT Admin</option>
                                <option value="3">User</option>
                              </select>
                            </div>


                             <div class="col-md-6" style="margin-top: 20px;">
                              <strong>Designation:</strong>
                              <select class="form-control" name="designation_id" required="" style="border-radius: 0rem;">
                                <option value="">---Select Designation---</option>
                                <?php
                                $qry = "select * from designation";
                                $run = mysqli_query($conn, $qry);
                                while ($row = mysqli_fetch_array($run)) { ?>
<option value="<?php echo $row["id"]; ?>"><?php echo $row["Designation"]; ?></option> <?php }
                                ?>
                              </select>

                            </div>
   


                            


                            <div class="col-md-6" style="margin-top: 20px;">
                              <strong>Password:</strong>
                              <input type="password" class="form-control" name="password" required="" placeholder="Enter Password..." style="border-radius: 0rem;" />
                            </div>
                            


                           



                             <div class="col-md-6" style="margin-top: 30px;">
          <div>
          <strong>Upload Image :</strong>
          <center> <br>
                      <input type="file" name="file1" id="file1" onChange="readURL1(this);" accept="image/gif, image/jpeg, image/png , image/jpg" />
   <br><br><img class="" id="blah1" src="https://miro.medium.com/v2/resize:fit:382/0*91v0rV9LQBJdPX7s.jpg" class="img-responsive img-rounded" alt="" style="margin-bottom: 08px; width: 150px; height: 150px;" />
                    </center>
                                 <script>
  function readURL1(input) {

     var maxfilesize = 1024 ** 2,  // 1 Mb
      filesize    = input.files[0].size,
      warningel   = document.getElementById( 'lbError' );

  if ( filesize > maxfilesize )
  {
   Swal.fire({
                              icon: 'warning',
                              title: 'Please select a file less than 2MB.',
                              // text: 'Submit',
                              // footer: '
                              // < a href > Why do I have this issue ? < /a>'
                            }).then(function() {
                              // Redirect the user
                              // window.location.href = "register.php";
                            });
                            event.target.value = '';
  }
  else
  {
     

  } 


         var ext = event.target.files[0].type.split('/')[1];
  var extArray = ['png', 'jpeg']
 if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah1')
                    .attr('src', e.target.result)
                    .width(140)
                    .height(145);
            };
      reader.readAsDataURL(input.files[0]);
        }
  else
{
   
}


      
        var ext = event.target.files[0].type.split('/')[1];
  var extArray = ['png', 'jpeg']
  if(extArray.indexOf(ext) == -1){
    Swal.fire({
                              icon: 'warning',
                              title: 'Please Select Only Image File !!',
                              // text: 'Submit',
                              // footer: '
                              // < a href > Why do I have this issue ? < /a>'
                            }).then(function() {
                              // Redirect the user
                              // window.location.href = "register.php";
                            });
                            event.target.value = '';
  }
  else
{
   
}

    }


  
</script>
          
        </div>
        </div>
   
                    
                          </div>
                        </div>
                      </div>
                      <br>
                      <div class="row" style="padding-top:5px; margin-bottom: 15px;">
                        <div class="col-md-12">
                       
                          <center><input type="submit" value="Submit" name="submit" class="btn btn-primary mt-5"></center>
                        </div>
                      </div>
                </form>
             </div>
            </div>

          </div>
          <!-- / Content -->

          
          

<?php if (isset($_POST["submit"])) {
    $type = $_POST["type"];
    $username = $_POST["username"];
    $firstname = $_POST["firstname"];
    $lastname = "";
    $email = $_POST["email"];
    $password = md5($_POST["password"]);
    $designation_id = $_POST["designation_id"];
    $department_id = $_POST["department_id"];

    $file1 = rand(1000, 100000) . "-" . $_FILES["file1"]["name"];
    $file1_loc = $_FILES["file1"]["tmp_name"];
    $tempname1 = $_FILES["file1"]["tmp_name"];

    $extension1 = pathinfo($_FILES["file1"]["name"], PATHINFO_EXTENSION);

    if ($extension1 == "jpg" || $extension1 == "jpeg" || $extension1 == "png") 
    {
        $qry="select * from users where username='$username'";
      $res=mysqli_query($conn,$qry);
      $data=mysqli_fetch_assoc($res);

      if($data==true)
      {
        ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'warning',
                                                      title: 'Emp ID Already Registered',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Add-Users.php";
                                                        });
                                                                </script>
      <?php
      }
      else{
        $qry="select * from users where email='$email'";
      $res=mysqli_query($conn,$qry);
      $data=mysqli_fetch_assoc($res);


      if($data==true)
      {
        ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'warning',
                                                      title: 'Email ID Already Registered',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Add-Users.php";
                                                        });
                                                                </script>
      <?php

      }
      else{

        
        $folder1 = "Profile/" . $file1;
        move_uploaded_file($file1_loc, $folder1);

        $sql = "INSERT INTO `users` (`username`, `firstname`, `lastname`, `email`, `password`, `type`, `designation_id`, `department_id`, `avatar`, `date_created`,`status`) VALUES ('$username', '$firstname', '$lastname', '$email', '$password', '$type', '$designation_id', '$department_id', '$file1', CURRENT_TIMESTAMP,'1')";

        $sqll = mysqli_query($conn, $sql);

        if ($sqll == true) { ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'success',
                                                      title: 'Add User Successfully',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Add-Users.php";
                                                        });
                                                                </script>
      <?php } else { ?>
             <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'error',
                                                      title: 'Error!!',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Add-Users.php";
                                                        });
                                                                </script>

      <?php }
      }
      }

    } else {
         ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'warning',
                                                      title: 'Please Select Only Image File !!',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Add-Users.php";
                                                        });
                                                                </script>
      <?php
    }
} ?>     

          
          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->

          
          

<!-- Footer -->
<?php include "Footer.php"; ?>
