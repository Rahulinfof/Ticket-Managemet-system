<?php include "Head.php"; ?>

<body>

  
  <!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar  ">
  <div class="layout-container">

    
    <?php if (isset($_GET["idd"])) {
            $idd = $_GET["idd"];
            $qry_equipment = " select * from equipment where id='$idd'";
            $run_equipment = mysqli_query($conn, $qry_equipment);
            @$var_equipment = mysqli_fetch_assoc($run_equipment);
            @$get_equipment_user_id = $var_equipment["user_id"];
            @$get_equipment_type = $var_equipment["equipment_type"];
            @$get_equipment_description = $var_equipment["equipment_description"];
            @$get_equipment_sno = $var_equipment["equipment_sno"];
            @$get_location = $var_equipment["location"];


            $qry_user_details = " select * from users where id='$get_equipment_user_id'";
            $run_user_details = mysqli_query($conn, $qry_user_details);
            @$var_user_details = mysqli_fetch_assoc($run_user_details);
            @$user_details_id = $var_user_details["id"];
            @$user_details_username=$var_user_details['firstname'];


    } ?>
    




<!-- Menu -->
<?php include "Menu.php"; ?>
<!-- / Menu -->

    

    <!-- Layout container -->
    <div class="layout-page">
      
      



<!-- Navbar -->
<?php include "Top-Header.php"; ?>  
<!-- / Navbar -->

      
      <!-- Content wrapper -->
      <div class="content-wrapper">

        <!-- Content -->
        
          <div class="container-xxl flex-grow-1 container-p-y">

            <div class="card mt-2" style="border-radius: 0px;">
             <div >
               <div class="card-body" style="border: 2px solid #182535; padding: 12px">
               <form id="reg_form" class="clearfix" name="reg_form" method="post" action="" enctype="multipart/form-data" autocomplete="off">
                 
                      <?php if (isset($_GET["idd"])) { ?>
                            <div class="bg-dark text-white" style="padding:5px;font-size: 18px;text-align: center;font-weight: bold;">Update Equipment</div>
                            <?php } else { ?>
                            <div class="bg-dark text-white" style="padding:5px;font-size: 18px;text-align: center;font-weight: bold;">Add Equipment</div>
                            <?php } ?>
                    <div class="row" style="margin-bottom: 15px;">
                      <div class="col-md-12">
                        <div class="form-group">
                          <div class="row">

                       <?php 
                         if($user_type=='1' || $user_type=='2')
                         {
                               ?>
                                <div class="col-md-<?php if($user_type=='1')
         {
        echo "3";
      }
      else{
        echo "4";
      }
       ?>" style="margin-top: 10px;">
                              <strong>User :</strong>
                              <select class="form-control" name="username" required style="border-radius: 0rem;">
                    <?php if (isset($_GET["idd"])) { ?>
                                  <option value="<?= $get_equipment_user_id ?>"><?= $user_details_username ?></option>
                                  <?php } 
                                  ?>
                                  <option value="">---Select User---</option>
                                <?php
           
 $qry="select * from users where type='3' ORDER BY id DESC";
 $run=mysqli_query($conn,$qry);
 while($row=mysqli_fetch_array($run))
 {
  ?>
<option value="<?php echo $row["id"]; ?>"><?php echo $row["firstname"]; ?></option>
 <?php
}
  ?>
                              </select>
                            </div>
                               <?php
                         }
                         else{

                         }
                        ?>
 
                           <?php if ($user_type=='1' || $user_type=='2')
                               {
                                ?>
                                   <input type="hidden" name="user_type" value="<?= $user_type ?>">
                                <?php

                               }
                               else{
                                ?>
                                <input type="hidden" name="user_type" value="<?= $user_type ?>">
                           <input type="hidden" name="username" value="<?= $user_id ?>">
                                <?php
                               }
                            ?>

                           <div class="col-md-<?php if($user_type=='1')
         {
        echo "3";
      }
      else{
        echo "4";
      }
       ?>" style="margin-top: 10px;">
                              <strong>Equipment Type :</strong>
                              <select class="form-control" name="equipment_type" required style="border-radius: 0rem;">
                                <?php if (isset($_GET["idd"])) { ?>
                                  <option value="<?= $get_equipment_type ?>"><?= $get_equipment_type ?></option>
                                  <?php } ?>
                                <option value="">---Select Equipment Type---</option>
                                <option value="Cartridges Print">Cartridges Print</option>
                                <option value="Mobile">Mobile</option>
                                <option value="Printer">Printer</option>
                                <option value="Desktop">Desktop</option>
                                <option value="TV">TV</option>
                                <option value="Mouse">Mouse</option>
                                <option value="Keyboard">Keyboard</option>
                                <option value="Cable">Cable</option>
                                <option value="Laptop Charger">Laptop Charger</option>
                                <option value="UPS Battery">UPS Battery</option>
                              </select>
                            </div>


                            <div class="col-md-<?php if($user_type=='1')
         {
        echo "3";
      }
      else{
        echo "4";
      }
       ?>" style="margin-top: 10px;">
                              <strong>Equipment S.No.</strong>
                              <input type="text" class="form-control" name="equipment_sno"

                              <?php if (isset($_GET["idd"])) { ?>
                                  value="<?= $get_equipment_sno ?>"
                                  <?php } else { ?>
                                  required="" placeholder="Enter Equipment S.No..."
                                  <?php } ?>

                                  style="border-radius: 0rem;" />
                            </div>

                            <div class="col-md-<?php if($user_type=='1')
         {
        echo "3";
      }
      else{
        echo "4";
      }
       ?>" style="margin-top: 10px;">
                              <strong>Location:</strong>
                              <input type="text" class="form-control" name="location"   <?php if (
                                  isset($_GET["idd"])
                              ) { ?>
                                  value="<?= $get_location ?>"
                                  <?php } else { ?>
                                  placeholder="Enter Location..." required=""
                                  <?php } ?> style="border-radius: 0rem;" />
                            </div>

                            <div class="col-md-12" style="margin-top: 10px;">
                              <strong>Equipment Description :</strong>
                               <?php if (isset($_GET["idd"])) { ?>
                                  <textarea class="form-control" id="editor" name="equipment_description" rows="15" required style="border-radius: 0rem;"><?= $get_equipment_description ?></textarea>
                                  <input type="hidden" value="<?= $idd ?>" name='idd'>
                                  <?php } else { ?>
                                  <textarea class="form-control" id="editor" name="equipment_description" rows="15" required style="border-radius: 0rem;"></textarea>
                                  <?php } ?>
                            </div>




                           

   
                    
                          </div>
                        </div>
                      </div>
                      <br>
                      <div class="row" style="padding-top:5px; margin-bottom: 15px;">
                        <div class="col-md-12">
                        <?php if (isset($_GET["idd"])) { ?>

                          <center><input type="submit" value="Update" name="update" class="btn btn-danger mt-5"></center>
                            <?php } else { ?>

                          <center><input type="submit" value="Submit" name="submit" class="btn btn-primary mt-5"></center>
                            <?php } ?>
                        </div>
                      </div>
                </form>
             </div>
            </div>

          </div>
          <!-- / Content -->

          
  <!-- Insert Query -->

<?php if (isset($_POST["submit"])) {
    $equipment_type = $_POST["equipment_type"];
    $equipment_description = $_POST["equipment_description"];
    $equipment_sno = $_POST["equipment_sno"];
    $location = $_POST["location"];

    $user_type = $_POST["user_type"];
    $user_idd = $_POST["username"];

    $status = "";
    if ($user_type == "1") {
        echo $status = "1";
    } elseif ($user_type == "2") {
        echo $status = "1";
    } else {
        echo $status = "0";
    }

    echo $sql = "INSERT INTO `equipment` (`user_id`,`equipment_type`, `equipment_description`, `equipment_sno`, `location`, `date_added`, `date_updated`, `status`) VALUES ('$user_idd','$equipment_type', '$equipment_description', '$equipment_sno', '$location',CURRENT_TIMESTAMP, CURRENT_TIMESTAMP,'$status')";

    $sqll = mysqli_query($conn, $sql);

    if ($sqll == true) { ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'success',
                                                      title: 'Equipment Add Successfully',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Equipment-List.php";
                                                        });
                                                                </script>
      <?php } else { ?>
             <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'error',
                                                      title: 'Error!!',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Add-Equipment.php";
                                                        });
                                                                </script>

      <?php }
} ?>     


<!-- Update Query -->

<?php if (isset($_POST["update"])) {
    $idd = $_POST["idd"];
    $username = $_POST["username"];
    $equipment_type = $_POST["equipment_type"];
    $equipment_description = $_POST["equipment_description"];
    $equipment_sno = $_POST["equipment_sno"];
    $location = $_POST["location"];

    $sql = "update equipment set user_id='$username',equipment_type='$equipment_type',equipment_description='$equipment_description',equipment_sno='$equipment_sno',location='$location',date_updated=CURRENT_TIMESTAMP where id='$idd'";

    $sqll = mysqli_query($conn, $sql);

    if ($sqll == true) { ?>

  <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'success',
                                                      title: 'Equipment Update Successfully',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Equipment-List.php";
                                                        });
                                                                </script>
      <?php } else { ?>
             <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'error',
                                                      title: 'Error!!',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Equipment-List.php";
                                                        });
                                                                </script>

      <?php }
} ?>   
          
          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->

          
          

<!-- Footer -->
<?php include "Footer.php"; ?>
