<?php include "Head.php"; ?>

<body>

  
  <!-- Layout wrapper -->
<div class="layout-wrapper layout-content-navbar  ">
  <div class="layout-container">

    
    

   


<!-- Menu -->
<?php include "Menu.php"; ?>
<!-- / Menu -->

    

    <!-- Layout container -->
    <div class="layout-page">
      
      



<!-- Navbar -->
<?php include "Top-Header.php"; ?>  
<!-- / Navbar -->

      
      <!-- Content wrapper -->
      <div class="content-wrapper">

        <!-- Content -->
        
          <div class="container-xxl flex-grow-1 container-p-y">
                   <?php if (
                       isset($_GET["type"]) &&
                       $_GET["type"] !== "" &&
                       isset($_GET["id"]) &&
                       $_GET["id"] > 0
                   ) {
                       $type = $_GET["type"];
                       $id = $_GET["id"];
                       if ($type == "0" || $type == "1") {
                           $status = "1";
                           if ($type == "1") {
                               $status = "0";
                           }
                           $sqll = "update equipment set status='$status' where id='$id'";
                           mysqli_query($conn, $sqll);
                       }
                   } ?>
                   <a href="Add-Equipment.php" title="" class="btn btn-sm btn-primary">Add Equipment</a>
            <div class="card" style="border-radius: 0px;margin-top: 10px;">
              <div style="border: 2px solid #182535; padding: 12px">
              <div class="bg-dark text-white" style="padding:5px;font-size: 18px;text-align: center;font-weight: bold;">Equipment List</div>
             <div class="card-body">
                 <input type="search" id="filter"  data-table="order-table" placeholder="Filtrer....." class="form-control light-table-filter" title="Type in a name">
                 <br>
            <!-- /.box-header -->
            <div class="box-body table-responsive">
              <table id="example" class="table table-responsive table-bordered table-hover order-table">
                <thead>
                <tr>
                  <?php if ($user_type == "1") { ?>
                     <th>Username</th>
                     <?php } ?>
                  <th>equipment_type</th>
                  <th>equipment_description</th>
                  <th>equipment_sno</th>
                  <th>location</th>
                  <th>date_added</th>
                  <th>date_updated</th>
                  <?php if ($user_type == "1") { ?>
                     <th>Status</th>
                     <?php } ?>
                  
                  <th colspan="2" class="text-center">Action</th>
                </tr>
                </thead>
                <tbody>
                         
     
                 <?php
                 $where = "";
                 if ($user_type == "3") {
                     $where = "equipment where user_id='$user_id' and status='1' ORDER BY id DESC";
                 } else {
                     $where = "equipment ORDER BY id DESC";
                 }

                 $qry = "select * from $where";
                 $run = mysqli_query($conn, $qry);

                 while ($var = mysqli_fetch_assoc($run)) { ?>
            <tr>
              <?php if ($user_type == "1") { ?>
                     <td><?php
                     $user_idd = $var["user_id"];
                     $qryy = " select * from users where id='$user_idd' ORDER BY id DESC";
                     $runn = mysqli_query($conn, $qryy);
                     $varr = mysqli_fetch_assoc($runn);
                     echo $firstname = $varr["firstname"];
                     ?></td>
                     <?php } ?>
            <td><?= $var["equipment_type"] ?></td>
            <td><?= $var["equipment_description"] ?></td>
            <td><?= $var["equipment_sno"] ?></td>
            <td><?= $var["location"] ?></td>
            <td><?= $var["date_added"] ?></td>
            <td><?= $var["date_updated"] ?></td> 
           <?php if ($user_type == "1") { ?><td>
                    <?php if ($var["status"] == "0") { ?>
                           <a href="?id=<?php echo $var[
                               "id"
                           ]; ?>&type=0"><label class="btn btn-danger btn-sm">Confirm by Admin</label></a>
                    <?php } else { ?>
                        <a href="?id=<?php echo $var[
                            "id"
                        ]; ?>&type=1"><label class="btn btn-success btn-sm blink">Active</label></a>
                    <?php } ?>
                     <?php } ?> </td>    
            <td>
              <center><a href="Add-Equipment.php?idd=<?php echo $var[
                  "id"
              ]; ?>" onclick="return confirm('Are You Sure Edit?')" class="btn btn-sm btn-primary">Edit</a></center>
            </td>
            <td>
              <center><a href="Equipment-List.php?idd=<?php echo $var[
                  "id"
              ]; ?>" onclick="return confirm('Are You Sure Delete?')" class="btn btn-sm btn-danger">Delete</a></center>
            </td>
            </tr>
            <?php }
                 ?>
                </tbody>
           
              </table>
            </div>
             </div>
            </div>
          </div>

          </div>
          <!-- / Content -->   

          
          <div class="content-backdrop fade"></div>
        </div>
        <!-- Content wrapper -->

          
          
<!-- Delete Query ALl Tabel -->


          <?php if (isset($_GET["idd"])) {
              $idd = $_GET["idd"];
              $result = $conn->query("DELETE FROM equipment WHERE id='$idd'");

              if ($result) { ?>
            <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'success',
                                                      title: 'Delete Successfull',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Equipment-List.php";
                                                        });
                                                                </script>
             <?php } else { ?>
              <script type="text/javascript">
                                                                   Swal.fire({
                                                      icon: 'error',
                                                      title: 'Not Delete',
                                                      // text: 'Submit',
                                                      // footer: '<a href>Why do I have this issue?</a>'
                                                    }).then(function() {
                                                        // Redirect the user
                                                        window.location.href = "Equipment-List.php";
                                                        });
                                                                </script>
                  <?php }
          } ?>
  
<!-- Footer -->
<?php include "Footer.php"; ?>
